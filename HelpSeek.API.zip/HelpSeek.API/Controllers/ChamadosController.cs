﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using HelpSeek.API.Models;
using Microsoft.Extensions.Configuration;

namespace HelpSeek.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ChamadosController : ControllerBase
    {
        private readonly IConfiguration _config;

        public ChamadosController(IConfiguration config)
        {
            _config = config;
        }

        private SqlConnection CreateConn()
            => new SqlConnection(_config.GetConnectionString("DefaultConnection"));

        // ✅ GET - Lista todos os chamados com nome do status
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var list = new List<SimpleChamado>();
            using var conn = CreateConn();
            await conn.OpenAsync();

            var sql = @"
                SELECT c.Id, c.Titulo, c.Descricao, s.Nome AS StatusNome, c.CriadoEm
                FROM Chamados c
                INNER JOIN Status s ON s.Id = c.StatusId
                ORDER BY c.Id DESC";

            using var cmd = new SqlCommand(sql, conn);
            using var reader = await cmd.ExecuteReaderAsync();

            while (await reader.ReadAsync())
            {
                list.Add(new SimpleChamado
                {
                    Id = reader.GetInt32(0),
                    Titulo = reader.IsDBNull(1) ? null : reader.GetString(1),
                    Descricao = reader.IsDBNull(2) ? null : reader.GetString(2),
                    Status = reader.IsDBNull(3) ? null : reader.GetString(3),
                    CriadoEm = reader.IsDBNull(4) ? DateTime.Now : reader.GetDateTime(4)
                });
            }

            return Ok(list);
        }

        // ✅ POST - Cria novo chamado
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] SimpleChamado dto)
        {
            using var conn = CreateConn();
            await conn.OpenAsync();

            // Status padrão = 1 (Aberto)
            int statusId = 1;

            var sql = @"
                INSERT INTO Chamados (Titulo, Descricao, UsuarioId, StatusId, CategoriaId, PrioridadeId)
                OUTPUT INSERTED.Id
                VALUES (@t, @d, 3, @s, 1, 2);";

            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@t", (object?)dto.Titulo ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@d", (object?)dto.Descricao ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@s", statusId);

            var newId = (int)await cmd.ExecuteScalarAsync();
            dto.Id = newId;
            dto.Status = "Aberto";
            dto.CriadoEm = DateTime.Now;

            return CreatedAtAction(nameof(GetAll), new { id = newId }, dto);
        }
    }
}
