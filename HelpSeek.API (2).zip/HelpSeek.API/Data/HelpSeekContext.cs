using Microsoft.EntityFrameworkCore;

namespace HelpSeek.API.Data
{
    // *** PLACEHOLDER CONTEXT ***
    // Este contexto será substituído pelo scaffold do EF Core com base no SEU banco HelpSeek.
    // Execute o comando abaixo no diretório do projeto para gerar as entidades reais:
    //
    // dotnet ef dbcontext scaffold "Server=victor\\mssqlserver01;Database=HelpSeek;Trusted_Connection=True;TrustServerCertificate=True;" Microsoft.EntityFrameworkCore.SqlServer -o Models -c HelpSeekContext --force
    //
    // Após o scaffold, você pode remover esta classe placeholder.
    public class HelpSeekContext : DbContext
    {
        public HelpSeekContext(DbContextOptions<HelpSeekContext> options) : base(options) { }
    }
}
