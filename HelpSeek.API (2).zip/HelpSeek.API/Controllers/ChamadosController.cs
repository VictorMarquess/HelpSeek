﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using HelpSeek.API.Models;

namespace HelpSeek.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ChamadosController : ControllerBase
    {
        private readonly IConfiguration _config;
        public ChamadosController(IConfiguration config) => _config = config;

        private SqlConnection CreateConn()
            => new SqlConnection(_config.GetConnectionString("DefaultConnection"));

        // ✅ GET - Lista todos os chamados
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var list = new List<SimpleChamado>();
            using var conn = CreateConn();
            await conn.OpenAsync();

            var sql = @"
                SELECT c.Id, c.Titulo, c.Descricao, s.Nome AS StatusNome, c.CriadoEm
                FROM Chamados c
                INNER JOIN Status s ON s.Id = c.StatusId
                ORDER BY c.Id DESC;";

            using var cmd = new SqlCommand(sql, conn);
            using var reader = await cmd.ExecuteReaderAsync();

            while (await reader.ReadAsync())
            {
                list.Add(new SimpleChamado
                {
                    Id = reader.GetInt32(0),
                    Titulo = reader.IsDBNull(1) ? null : reader.GetString(1),
                    Descricao = reader.IsDBNull(2) ? null : reader.GetString(2),
                    Status = reader.IsDBNull(3) ? null : reader.GetString(3),
                    CriadoEm = reader.IsDBNull(4) ? DateTime.Now : reader.GetDateTime(4)
                });
            }

            return Ok(list);
        }

        // ✅ GET - Meus chamados (para o app)
        [HttpGet("meus")]
        public async Task<IActionResult> GetMine([FromQuery] int usuarioId)
        {
            var list = new List<SimpleChamado>();
            using var conn = CreateConn();
            await conn.OpenAsync();

            var sql = @"
                SELECT c.Id, c.Titulo, c.Descricao, s.Nome AS StatusNome, c.CriadoEm
                FROM Chamados c
                INNER JOIN Status s ON s.Id = c.StatusId
                WHERE c.UsuarioId = @u
                ORDER BY c.Id DESC;";

            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@u", usuarioId);

            using var reader = await cmd.ExecuteReaderAsync();
            while (await reader.ReadAsync())
            {
                list.Add(new SimpleChamado
                {
                    Id = reader.GetInt32(0),
                    Titulo = reader.IsDBNull(1) ? null : reader.GetString(1),
                    Descricao = reader.IsDBNull(2) ? null : reader.GetString(2),
                    Status = reader.IsDBNull(3) ? null : reader.GetString(3),
                    CriadoEm = reader.GetDateTime(4)
                });
            }

            return Ok(list);
        }

        // ✅ POST - Cria novo chamado (usando DTO)
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateChamadoDto dto)
        {
            using var conn = CreateConn();
            await conn.OpenAsync();

            // Status padrão: "Aberto" (Id = 1)
            int statusId = 1;

            var sql = @"
                INSERT INTO Chamados (UsuarioId, Titulo, Descricao, StatusId, CriadoEm)
                OUTPUT INSERTED.Id
                VALUES (@u, @t, @d, @s, SYSDATETIME());";

            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@u", dto.UsuarioId);
            cmd.Parameters.AddWithValue("@t", (object?)dto.Titulo ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@d", (object?)dto.Descricao ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@s", statusId);

            var newId = Convert.ToInt32(await cmd.ExecuteScalarAsync());

            return CreatedAtAction(nameof(GetAll), new { id = newId }, new
            {
                Id = newId,
                dto.Titulo,
                dto.Descricao,
                Status = "Aberto",
                CriadoEm = DateTime.Now
            });
        }

        // ✅ PUT - Atualiza status
        [HttpPut("{id}/status")]
        public async Task<IActionResult> UpdateStatus(int id, [FromBody] UpdateStatusDto dto)
        {
            using var conn = CreateConn();
            await conn.OpenAsync();

            var sql = @"
                UPDATE c SET c.StatusId = s.Id
                FROM Chamados c
                INNER JOIN Status s ON s.Nome = @status
                WHERE c.Id = @id;";

            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@status", dto.Status);
            cmd.Parameters.AddWithValue("@id", id);

            var rows = await cmd.ExecuteNonQueryAsync();
            return rows > 0 ? NoContent() : NotFound();
        }
    }
}
