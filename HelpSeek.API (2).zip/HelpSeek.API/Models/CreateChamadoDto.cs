namespace HelpSeek.API.Models
{
    public class CreateChamadoDto
    {
        public int UsuarioId { get; set; }
        public string? Titulo { get; set; }
        public string? Descricao { get; set; }
        public string? Prioridade { get; set; }
        public string? Categoria { get; set; }
    }
}
